<?php
include_once "php/front/imc.php";
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Calculadora de IMC</title>
</head>

<body>

    <nav class="p-3 mb-2 bg-success text-white">
        <div class="container-fluid">
            <h1>Calcular IMC</h1>
            </a>
        </div>
    </nav>

    <form method="post" action="">
        <table>
            <div class="mb-3 row">
                <label for="altura" class="col-sm-3 col-form-label text-primary">Altura</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control text-primary"
                        name="altura" value="0">
                </div>
            </div>
            </tr>
            <div class="mb-3 row">
                <label for="peso" class="col-sm-3 col-form-label text-primary">Peso</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control text-primary" id="peso"
                        name="peso" value="0">
                </div>
            </div>
            <div class="mb-6 row">
                <button type="submit" class="btn btn-success col-sm-3 m-2">Guardar</button>
                <button type="reset" class="btn btn-danger col-sm-3 m-2">Borrar</button>
            </div>
            <div class="mb-3 row">
                <label for="resultado" class="col-sm-3 col-form-label text-primary">Estado: </label>
                <div class="col-sm-9">
                    <input type="text" class="form-control text-primary" id="resultado"
                        name="resultado" value="<?php echo $resultado ?>">
                </div>
            </div>
        </table>
    </form>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>