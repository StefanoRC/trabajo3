<?php

$resultado = "";
if (isset($_REQUEST['altura']) && isset($_REQUEST['peso'])) {
    $altura = $_REQUEST['altura'];
    $peso = $_REQUEST['peso'];
    $resultado = indiceMasaMuscular($altura, $peso);
}

function indiceMasaMuscular($altura, $peso)
{
    if ($altura == 0) {
        return "Ingrese un valor correcto";
    } else if ($peso == 0) {
        return "Ingrese un valor correcto";
    }

    $alturaM = $altura / 100;
    $indice = $peso / ($alturaM * $alturaM);
    $indice = round($indice, 2);


    switch (true) {

        case $indice <= 15.99:
            return $indice . " Delgadez severa";

        case $indice >= 16 & $indice <= 18.49:
            return $indice . " Delgadez";

        case $indice >= 18.50 & $indice <= 24.99:
            return $indice . " Peso Normal";

        case $indice >= 25 & $indice <= 29.99:
            return $indice . " Sobrepeso";

        case $indice >= 30 & $indice <= 34.99:
            return $indice . " Obesidad Moderada";

        case $indice >= 35 & $indice <= 39.99:
            return $indice . " Obesidad Severa";

        default:
            return " Obesidad Morbida";
    }
}
